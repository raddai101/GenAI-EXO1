# Car-Traffic-simulator
This repo is a project to simulate a cross-road traffic. The main objective is to avoid collision of cars and respect traffic lights during maximum of 10 seconds.

## This is a Simple git commit test

Fenêtre principale
        self.root = tk.Tk()
        self.root.title("Simulateur de Trafic - Carrefour à 4 Routes")
        self.x_ = int(self.root.winfo_screenwidth())
        self.y_ = int(self.root.winfo_screenheight())
        self.window_width = 800
        self.window_height = 700
        self.center_x = (self.x_ // 2) - (self.window_width // 2)
        self.center_y = (self.y_ // 2) - (self.window_height // 2)
        self.root.geometry(f"{self.window_width}x{self.window_height}+{self.center_x}+{self.center_y}")
        self.root.resizable(False, False)