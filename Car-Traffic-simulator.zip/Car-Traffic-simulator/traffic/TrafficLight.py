class TrafficLight:
    def __init__(self, position, green_duration=15, yellow_duration=3, red_duration=15):
        self.position = position  # "nord", "sud", "est", "ouest"
        self.state = "red"  # "green", "yellow", "red"
        self.timer = 0
        self.green_duration = green_duration
        self.yellow_duration = yellow_duration
        self.red_duration = red_duration
        
        # Couleurs des états
        self.colors = {
            "green": "green",
            "yellow": "yellow",
            "red": "red"
        }
        
        
        self.positions = {
            "nord": (500, 300),   
            "sud": (300, 500),    
            "est": (500, 500),    
            "ouest": (300, 300)   
        }
        
        # Orientation du feu (dans quelle direction il regarde)
        self.orientations = {
            "nord": "down",
            "sud": "up",
            "est": "left",
            "ouest": "right"
        }
        
        self.rotation_angles = {
            "nord": 0,
            "sud": 180,
            "est": 90,
            "ouest": -90
        }

    def update(self, delta_time):
        """Met à jour l'état du feu en fonction du temps"""
        self.timer += delta_time
        
        if self.state == "green":
            if self.timer >= self.green_duration:
                self.state = "yellow"
                self.timer = 0
        elif self.state == "yellow":
            if self.timer >= self.yellow_duration:
                self.state = "red"
                self.timer = 0
        elif self.state == "red":
            if self.timer >= self.red_duration:
                self.state = "green"
                self.timer = 0

    def set_state(self, state):
        """Force un état spécifique"""
        self.state = state
        self.timer = 0

    def is_green(self):
        return self.state == "green"

    def is_yellow(self):
        return self.state == "yellow"

    def is_red(self):
        return self.state == "red"

    def draw(self, canvas):
        """Dessine le feu sur le canvas avec la bonne orientation"""
        x, y = self.positions[self.position]
        
        # Couleurs des feux
        colors = {
            "red": "#ff0000",
            "yellow": "#ffcc00", 
            "green": "#00cc00"
        }
        
        
        if self.position in ["nord", "sud"]:
            # Poteau vertical
            canvas.create_line(x, y+30, x, y+50, fill="black", width=5, tags=("traffic_light",))
            canvas.create_rectangle(x-3, y-5, x+3, y+30, fill="black", tags=("traffic_light",))
        else:
            # Poteau horizontal
            canvas.create_line(x-30, y, x-50, y, fill="black", width=5, tags=("traffic_light",))
            canvas.create_rectangle(x-30, y-3, x+5, y+3, fill="black", tags=("traffic_light",))
        
        # Dessiner le boîtier du feu (avec rotation selon la position)
        if self.position in ["nord", "sud"]:
            # Orientation verticale
            canvas.create_rectangle(x-14, y-30, x+14, y+30, fill="black", outline="darkgray", width=2,
                                    tags=("traffic_light",))
            
            # Les 3 lumières (rouge, jaune, vert) de haut en bas
            for i, (state, color) in enumerate([("red", colors["red"]), 
                                                ("yellow", colors["yellow"]), 
                                                ("green", colors["green"])]):
                y_pos = y - 18 + (i * 18)
                fill_color = color if self.state == state else "#333333"
                canvas.create_oval(x-9, y_pos-7, x+9, y_pos+7, fill=fill_color, outline="white", width=1,
                                   tags=("traffic_light",))
        else:
            # Orientation horizontale
            canvas.create_rectangle(x-30, y-14, x+30, y+14, fill="black", outline="darkgray", width=2,
                                    tags=("traffic_light",))
            
            # Les 3 lumières (rouge, jaune, vert) de gauche à droite
            if self.position == "est":
                light_order = [("green", colors["green"]), 
                              ("yellow", colors["yellow"]), 
                              ("red", colors["red"])]
            else:  # ouest
                light_order = [("red", colors["red"]), 
                              ("yellow", colors["yellow"]), 
                              ("green", colors["green"])]
            
            for i, (state, color) in enumerate(light_order):
                x_pos = x - 18 + (i * 18)
                fill_color = color if self.state == state else "#333333"
                canvas.create_oval(x_pos-7, y-9, x_pos+7, y+9, fill=fill_color, outline="white", width=1,
                                   tags=("traffic_light",))
        
        # Ajouter une petite étiquette pour identifier le feu
        canvas.create_text(x, y+40 if self.position in ["nord", "sud"] else y-40,
                          text=f"🚦{self.position[:3].upper()}", 
                          fill="white", font=("Arial", 8, "bold"),
                          tags=("traffic_light",))
