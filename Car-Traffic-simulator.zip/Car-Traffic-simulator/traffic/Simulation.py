import tkinter as tk
import random
from .RoadSystem import RoadSystem
from .TrafficLightSystem import TrafficLightSystem
from .car import Car

class Simulation:
    def __init__(self, canvas):
        self.canvas = canvas
        self.canvas_width = 800
        self.canvas_height = 800
        
        # Initialiser les systèmes
        self.road_system = RoadSystem(self.canvas_width, self.canvas_height)
        self.traffic_light_system = TrafficLightSystem()
        
        # Liste des voitures
        self.cars = []
        self.max_cars = 60
        
        # Compteurs
        self.car_generation_counter = 0
        self.generation_interval = 20  # frames entre chaque génération (réduit pour plus de voitures)
        self.total_cars_generated = 0
        self.time_counter = 0
        
        # État de la simulation
        self.running = False
        self.paused = False
        
        # Variables de performance
        self.frame_count = 0
        
        # Dessiner le fond
        self.draw_background()
        
        # Dessiner les routes
        self.road_system.draw_roads(self.canvas)
        
        # Dessiner les feux
        self.traffic_light_system.draw(self.canvas)

    def draw_background(self):
        """Dessine le fond de la simulation"""
        # Fond vert (pelouse)
        self.canvas.create_rectangle(0, 0, self.canvas_width, self.canvas_height, 
                                    fill="#2d8a2d", outline="", tags="background")
        
        # Ajouter un peu de texture (herbe)
        for _ in range(200):
            x = random.randint(0, self.canvas_width)
            y = random.randint(0, self.canvas_height)
            color = random.choice(["#3a9a3a", "#2d8a2d", "#4aaa4a", "#1d7a1d"])
            self.canvas.create_oval(x, y, x+3, y+3, fill=color, outline="", tags="background")

    def start(self):
        """Démarre la simulation"""
        if not self.running:
            self.running = True
            self.paused = False
            print("Simulation démarrée !")
            self.update()
    
    def pause(self):
        """Met la simulation en pause"""
        self.paused = not self.paused
        print("Simulation en pause" if self.paused else "Simulation reprise")
    
    def reset(self):
        """Réinitialise la simulation"""
        self.paused = True
        self.running = False
        
        # Supprimer toutes les voitures
        for car in self.cars:
            car.remove(self.canvas)
        self.cars.clear()
        
        # Réinitialiser les compteurs
        self.total_cars_generated = 0
        self.car_generation_counter = 0
        self.time_counter = 0
        self.frame_count = 0
        
        # Redessiner le fond
        self.canvas.delete("all")
        self.draw_background()
        self.road_system.draw_roads(self.canvas)
        self.traffic_light_system.draw(self.canvas)
        
        print("Simulation réinitialisée !")

    def update(self):
        """Boucle principale de la simulation"""
        if not self.running or self.paused:
            # Continuer à vérifier même en pause
            self.canvas.after(50, self.update)
            return
        
        self.frame_count += 1
        delta_time = 0.05  # 50ms en secondes
        
        # Mettre à jour le temps
        self.time_counter += delta_time
        
        # 1. Mettre à jour les feux
        self.traffic_light_system.update(delta_time)
        
        # 2. Générer de nouvelles voitures
        self.generate_cars()
        
        # 3. Mettre à jour les voitures
        self.update_cars()
        
        # 4. Supprimer les voitures terminées
        self.remove_finished_cars()
        
        # 5. Redessiner tout
        self.redraw()
        
        # 6. Planifier la prochaine mise à jour
        self.canvas.after(50, self.update)
    
    def generate_cars(self):
        """Génère de nouvelles voitures"""
        if len(self.cars) >= self.max_cars:
            return
        
        self.car_generation_counter += 1
        
        # Générer une voiture tous les X frames
        if self.car_generation_counter >= self.generation_interval:
            self.car_generation_counter = 0
            
            # Créer une nouvelle voiture
            car = Car(self.road_system)
            self.cars.append(car)
            self.total_cars_generated += 1
            
            # DEBUG
            # print(f"🚗 Voiture {car.id} générée direction {car.direction} | Total: {len(self.cars)}")
    
    def update_cars(self):
        """Met à jour toutes les voitures"""
        for car in self.cars:
            if car.state != "finished":
                car.update(self.traffic_light_system, self.cars)
    
    def remove_finished_cars(self):
        """Supprime les voitures qui ont terminé leur trajet"""
        finished_cars = [car for car in self.cars if car.state == "finished"]
        for car in finished_cars:
            car.remove(self.canvas)
            self.cars.remove(car)
            # print(f"Voiture {car.id} retirée ! Reste: {len(self.cars)}")
    
    def redraw(self):
        """Redessine tous les éléments (plus efficace)"""
        # CORRECTION DU BUG PRINCIPAL :
        # L'ancien code faisait self.canvas.delete("car") / "car_*" / "dir_*"
        # ICI, ce qui détruisait physiquement les rectangles des voitures sur
        # le canvas. Mais chaque objet Car gardait son ancien `canvas_id` (il
        # n'était jamais remis à None), donc à la frame suivante,
        # car.draw() appelait canvas.coords(self.canvas_id, ...) sur un
        # identifiant qui n'existait plus -> erreur Tkinter -> la boucle
        # update() s'interrompait avant de se replanifier elle-même.
        # Résultat : la simulation se figeait après 1 frame et les voitures
        # n'apparaissaient (presque) jamais.
        #
        # La méthode Car.draw() gère déjà très bien elle-même la mise à jour
        # (canvas.coords si la voiture existe déjà, canvas.create_rectangle
        # sinon) : il ne faut donc PAS supprimer les voitures à chaque frame,
        # juste les laisser se déplacer/se dessiner normalement.
        
        # Redessiner les feux (ils peuvent changer d'état) - eux, on les
        # supprime bien via leur tag "traffic_light" avant de les redessiner.
        self.canvas.delete("traffic_light")
        self.traffic_light_system.draw(self.canvas)
        
        # Mettre à jour / dessiner les voitures
        for car in self.cars:
            car.draw(self.canvas)
