from .TrafficLight import TrafficLight

class TrafficLightSystem:
    def __init__(self):
        self.lights = {
            "nord": TrafficLight("nord"),   
            "sud": TrafficLight("sud"),     
            "est": TrafficLight("est"),     
            "ouest": TrafficLight("ouest")  
        }
        
        # Phase actuelle : "main" (nord/sud) ou "lateral" (est/ouest)
        self.phase = "main"
        self.phase_timer = 0
        self.phase_duration = 20  # secondes (réduit pour tester)
        
        # Initialiser les états
        self.initialize_lights()
    
    def initialize_lights(self):
        """Initialise les feux avec les bons états"""
        self.lights["nord"].set_state("green")
        self.lights["sud"].set_state("green")
        self.lights["est"].set_state("red")
        self.lights["ouest"].set_state("red")
        self.phase = "main"
        print("🟢 Feux initialisés: Nord/Sud = VERT, Est/Ouest = ROUGE")

    def update(self, delta_time):
        """Met à jour tous les feux"""
        # Mettre à jour chaque feu individuellement
        for light in self.lights.values():
            light.update(delta_time)
        
        # Gestion de la phase
        self.phase_timer += delta_time
        
        # Si la phase est terminée, alterner
        if self.phase_timer >= self.phase_duration:
            self.switch_phase()
            self.phase_timer = 0

    def switch_phase(self):
        """Alterne entre les phases main et lateral"""
        if self.phase == "main":
            # Passer en phase latérale (est/ouest verts)
            for direction in ["nord", "sud"]:
                self.lights[direction].set_state("red")
            for direction in ["est", "ouest"]:
                self.lights[direction].set_state("green")
            self.phase = "lateral"
            print("🔴 Phase latérale activée (Est/Ouest = VERT)")
        else:
            # Passer en phase principale (nord/sud verts)
            for direction in ["nord", "sud"]:
                self.lights[direction].set_state("green")
            for direction in ["est", "ouest"]:
                self.lights[direction].set_state("red")
            self.phase = "main"
            print("🟢 Phase principale activée (Nord/Sud = VERT)")

    def get_light_for_direction(self, direction):
        """Retourne le feu correspondant à une direction"""
        return self.lights[direction]

    def draw(self, canvas):
        """Dessine tous les feux"""
        # Dessiner chaque feu avec son tag
        for light in self.lights.values():
            light.draw(canvas)