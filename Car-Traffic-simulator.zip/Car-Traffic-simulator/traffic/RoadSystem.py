class RoadSystem:
    def __init__(self, canvas_width=800, canvas_height=800):
        self.canvas_width = canvas_width
        self.canvas_height = canvas_height
        self.center_x = canvas_width // 2
        self.center_y = canvas_height // 2
        
        # Dimensions des routes
        self.road_width = 80
        self.road_length = 300
        self.road_half = self.road_width // 2
        self.intersection_size = 40  # Taille de l'intersection carrée
        
        # Définir les zones de chaque route
        self.routes = {
            "nord": {
                "x1": self.center_x - self.road_half,
                "y1": 100,
                "x2": self.center_x + self.road_half,
                "y2": self.center_y - self.intersection_size
            },
            "sud": {
                "x1": self.center_x - self.road_half,
                "y1": self.center_y + self.intersection_size,
                "x2": self.center_x + self.road_half,
                "y2": self.canvas_height - 100
            },
            "est": {
                "x1": self.center_x + self.intersection_size,
                "y1": self.center_y - self.road_half,
                "x2": self.canvas_width - 100,
                "y2": self.center_y + self.road_half
            },
            "ouest": {
                "x1": 100,
                "y1": self.center_y - self.road_half,
                "x2": self.center_x - self.intersection_size,
                "y2": self.center_y + self.road_half
            }
        }
        
        # Lignes d'arrêt (avant l'intersection)
        self.stop_lines = {
            "nord": self.center_y - self.intersection_size - 20,
            "sud": self.center_y + self.intersection_size + 20,
            "est": self.center_x + self.intersection_size + 20,
            "ouest": self.center_x - self.intersection_size - 20
        }
        
        # Définir les voies pour chaque direction
        self.lanes = {
            "nord": {"droite": self.center_x + 20, "gauche": self.center_x - 20},
            "sud": {"droite": self.center_x - 20, "gauche": self.center_x + 20},
            "est": {"droite": self.center_y + 20, "gauche": self.center_y - 20},
            "ouest": {"droite": self.center_y - 20, "gauche": self.center_y + 20}
        }
        
        # Coins de l'intersection (pour placer les feux)
        self.corners = {
            "nord": (self.center_x - self.intersection_size, self.center_y - self.intersection_size),
            "sud": (self.center_x + self.intersection_size, self.center_y + self.intersection_size),
            "est": (self.center_x + self.intersection_size, self.center_y - self.intersection_size),
            "ouest": (self.center_x - self.intersection_size, self.center_y + self.intersection_size)
        }

    def draw_roads(self, canvas):
        """Dessine toutes les routes sur le canvas"""
        # Route Nord
        canvas.create_rectangle(
            self.routes["nord"]["x1"], self.routes["nord"]["y1"],
            self.routes["nord"]["x2"], self.routes["nord"]["y2"],
            fill="#555555", outline="#444444"
        )
        
        # Route Sud
        canvas.create_rectangle(
            self.routes["sud"]["x1"], self.routes["sud"]["y1"],
            self.routes["sud"]["x2"], self.routes["sud"]["y2"],
            fill="#555555", outline="#444444"
        )
        
        # Route Est
        canvas.create_rectangle(
            self.routes["est"]["x1"], self.routes["est"]["y1"],
            self.routes["est"]["x2"], self.routes["est"]["y2"],
            fill="#555555", outline="#444444"
        )
        
        # Route Ouest
        canvas.create_rectangle(
            self.routes["ouest"]["x1"], self.routes["ouest"]["y1"],
            self.routes["ouest"]["x2"], self.routes["ouest"]["y2"],
            fill="#555555", outline="#444444"
        )
        
        # Intersection centrale (carrefour)
        canvas.create_rectangle(
            self.center_x - self.intersection_size, 
            self.center_y - self.intersection_size,
            self.center_x + self.intersection_size, 
            self.center_y + self.intersection_size,
            fill="#666666", outline="#444444"
        )
        
        # Lignes de séparation des voies
        self._draw_lane_lines(canvas)
        
        # Lignes d'arrêt
        self._draw_stop_lines(canvas)
        
        # Marquage des coins de l'intersection (pour visualiser où vont les feux)
        self._draw_corners(canvas)

    def _draw_lane_lines(self, canvas):
        """Dessine les lignes de séparation des voies"""
        # Ligne Nord-Sud (verticale)
        canvas.create_line(
            self.center_x, 100, 
            self.center_x, self.center_y - self.intersection_size,
            fill="white", dash=(8, 8), width=2
        )
        canvas.create_line(
            self.center_x, self.center_y + self.intersection_size, 
            self.center_x, self.canvas_height - 100,
            fill="white", dash=(8, 8), width=2
        )
        
        # Ligne Est-Ouest (horizontale)
        canvas.create_line(
            100, self.center_y, 
            self.center_x - self.intersection_size, self.center_y,
            fill="white", dash=(8, 8), width=2
        )
        canvas.create_line(
            self.center_x + self.intersection_size, self.center_y, 
            self.canvas_width - 100, self.center_y,
            fill="white", dash=(8, 8), width=2
        )

    def _draw_stop_lines(self, canvas):
        """Dessine les lignes d'arrêt"""
        # Lignes pour chaque direction
        stop_line_width = 30
        canvas.create_line(
            self.center_x - stop_line_width, self.stop_lines["nord"],
            self.center_x + stop_line_width, self.stop_lines["nord"],
            fill="white", width=3
        )
        canvas.create_line(
            self.center_x - stop_line_width, self.stop_lines["sud"],
            self.center_x + stop_line_width, self.stop_lines["sud"],
            fill="white", width=3
        )
        canvas.create_line(
            self.stop_lines["est"], self.center_y - stop_line_width,
            self.stop_lines["est"], self.center_y + stop_line_width,
            fill="white", width=3
        )
        canvas.create_line(
            self.stop_lines["ouest"], self.center_y - stop_line_width,
            self.stop_lines["ouest"], self.center_y + stop_line_width,
            fill="white", width=3
        )
    
    def _draw_corners(self, canvas):
        """Dessine des petits marqueurs aux coins de l'intersection"""
        # Afficher les coins avec des petits cercles colorés
        corner_colors = {
            "nord": "yellow",
            "sud": "yellow", 
            "est": "yellow",
            "ouest": "yellow"
        }
        
        for corner_name, (x, y) in self.corners.items():
            canvas.create_oval(x-5, y-5, x+5, y+5, fill=corner_colors[corner_name], outline="black")

    def get_lane_position(self, direction, lane="droite"):
        """Retourne la position x ou y de la voie selon la direction"""
        if direction in ["nord", "sud"]:
            return self.lanes[direction][lane]
        else:
            return self.lanes[direction][lane]

    def is_in_intersection(self, x, y):
        """Vérifie si une position est dans l'intersection"""
        return (self.center_x - self.intersection_size <= x <= self.center_x + self.intersection_size and
                self.center_y - self.intersection_size <= y <= self.center_y + self.intersection_size)

    def is_at_stop_line(self, direction, x, y):
        """Vérifie si une voiture est à la ligne d'arrêt"""
        margin = 5
        if direction == "nord":
            return abs(y - self.stop_lines["nord"]) <= margin
        elif direction == "sud":
            return abs(y - self.stop_lines["sud"]) <= margin
        elif direction == "est":
            return abs(x - self.stop_lines["est"]) <= margin
        elif direction == "ouest":
            return abs(x - self.stop_lines["ouest"]) <= margin
        return False

    def get_exit_direction(self, entry_direction, turn):
        """Calcule la direction de sortie en fonction de l'entrée et du virage"""
        if turn == "straight":
            return entry_direction
        elif turn == "right":
            if entry_direction == "nord": return "est"
            if entry_direction == "sud": return "ouest"
            if entry_direction == "est": return "sud"
            if entry_direction == "ouest": return "nord"
        elif turn == "left":
            if entry_direction == "nord": return "ouest"
            if entry_direction == "sud": return "est"
            if entry_direction == "est": return "nord"
            if entry_direction == "ouest": return "sud"
        return entry_direction