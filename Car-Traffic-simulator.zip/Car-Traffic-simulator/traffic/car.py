import random
import math

class Car:
    car_id = 0
    
    def __init__(self, road_system):
        Car.car_id += 1
        self.id = Car.car_id
        
        # Référence au système routier
        self.road_system = road_system
        
        # Dimensions
        self.width = 15
        self.height = 30
        
        # Couleur aléatoire
        self.color = random.choice(["red", "blue", "green", "yellow", "orange", "purple", "pink"])
        
        # Direction initiale
        self.direction = random.choice(["nord", "sud", "est", "ouest"])
        self.speed = random.uniform(1.0, 2.5)
        self.normal_speed = self.speed
        
        # Position initiale
        self.x, self.y = self.get_start_position()
        
        # Destination (sera choisie à l'intersection)
        self.destination = None
        self.has_chosen_direction = False
        
        # État
        self.state = "moving"  # "moving", "stopped", "turning", "finished"
        self.is_at_intersection = False
        self.has_turned = False
        
        # Pour le virage
        self.turn_progress = 0
        self.turn_start_x = 0
        self.turn_start_y = 0
        self.turn_radius = 50
        
        # Pour la détection de collision
        self.stop_distance = 20
        
        # Comportement
        self.stopped_at_light = False
        
        # Identifiant tkinter
        self.canvas_id = None
    
    def get_start_position(self):
        """Retourne la position de départ selon la direction"""
        center_x = self.road_system.center_x
        center_y = self.road_system.center_y
        
        if self.direction == "nord":
            lane_x = self.road_system.get_lane_position("nord", "droite")
            return lane_x, 100 + random.randint(0, 50)
        elif self.direction == "sud":
            lane_x = self.road_system.get_lane_position("sud", "droite")
            return lane_x, 700 - random.randint(0, 50)
        elif self.direction == "est":
            lane_y = self.road_system.get_lane_position("est", "droite")
            return 700 - random.randint(0, 50), lane_y
        else:  # ouest
            lane_y = self.road_system.get_lane_position("ouest", "droite")
            return 100 + random.randint(0, 50), lane_y

    def choose_direction(self):
        """Choisit aléatoirement la direction à prendre"""
        if self.is_at_intersection and not self.has_chosen_direction:
            # Choix pondéré : 50% tout droit, 30% droite, 20% gauche
            choices = ["straight", "right", "left"]
            weights = [0.33, 0.33, 0.33]
            self.destination = random.choices(choices, weights=weights)[0]
            self.has_chosen_direction = True

    def update(self, traffic_light_system, other_cars):
        """Met à jour la position et l'état de la voiture"""
        if self.state == "finished":
            return
            
        # Vérifier si on est à l'intersection
        if self.road_system.is_in_intersection(self.x, self.y):
            self.is_at_intersection = True
            self.choose_direction()
        
        # Vérifier le feu
        light = traffic_light_system.get_light_for_direction(self.direction)
        if self.road_system.is_at_stop_line(self.direction, self.x, self.y):
            if light.is_red() or light.is_yellow():
                self.speed = 0
                self.stopped_at_light = True
                return
            else:
                self.stopped_at_light = False
        
        # Vérifier les collisions avec les autres voitures
        self.speed = self.normal_speed
        for car in other_cars:
            if car.id == self.id or car.state == "finished":
                continue
            
            # Détection par distance
            distance = self._get_distance(car)
            if distance < self.stop_distance:
                self.speed = 0
                break
                
            # Détection par boîtes englobantes
            if self._check_collision(car):
                self.speed = 0
                break
        
        # Appliquer le mouvement
        self._move()
        
        # Gérer le virage si nécessaire
        if self.is_at_intersection and self.has_chosen_direction and not self.has_turned:
            if self.destination != "straight":
                self._start_turn()
        
        # Si en train de tourner, continuer le virage
        if self.state == "turning":
            self._continue_turn()
        
        # Vérifier si la voiture a quitté la route
        if self._is_off_road():
            self.state = "finished"
    
    def _move(self):
        """Déplace la voiture en ligne droite"""
        if self.speed == 0:
            return
            
        if self.direction == "nord":
            self.y -= self.speed
        elif self.direction == "sud":
            self.y += self.speed
        elif self.direction == "est":
            self.x += self.speed
        elif self.direction == "ouest":
            self.x -= self.speed
    
    def _start_turn(self):
        """Démarre le virage"""
        self.state = "turning"
        self.turn_progress = 0
        self.turn_start_x = self.x
        self.turn_start_y = self.y
        
        # Calculer la direction de sortie
        self.exit_direction = self.road_system.get_exit_direction(
            self.direction, self.destination
        )

    def _continue_turn(self):
        """Continue le virage en utilisant un arc de Bézier simplifié"""
        self.turn_progress += 0.02
        
        if self.turn_progress >= 1:
            self.turn_progress = 1
            self.has_turned = True
            self.state = "moving"
            self.direction = self.exit_direction
            self.is_at_intersection = False
            return
        
        # Bézier simplifié pour les virages
        t = self.turn_progress
        cx = self.road_system.center_x
        cy = self.road_system.center_y
        
        if self.direction == "nord" and self.destination == "right":
            # Nord -> Est (virage à droite)
            self.x = cx + self.turn_radius * math.sin(t * math.pi / 2)
            self.y = cy - self.turn_radius * math.cos(t * math.pi / 2)
        elif self.direction == "nord" and self.destination == "left":
            # Nord -> Ouest (virage à gauche)
            self.x = cx - self.turn_radius * math.sin(t * math.pi / 2)
            self.y = cy - self.turn_radius * math.cos(t * math.pi / 2)
        elif self.direction == "sud" and self.destination == "right":
            # Sud -> Ouest (virage à droite)
            self.x = cx - self.turn_radius * math.sin(t * math.pi / 2)
            self.y = cy + self.turn_radius * math.cos(t * math.pi / 2)
        elif self.direction == "sud" and self.destination == "left":
            # Sud -> Est (virage à gauche)
            self.x = cx + self.turn_radius * math.sin(t * math.pi / 2)
            self.y = cy + self.turn_radius * math.cos(t * math.pi / 2)
        elif self.direction == "est" and self.destination == "right":
            # Est -> Sud (virage à droite)
            self.x = cx + self.turn_radius * math.cos(t * math.pi / 2)
            self.y = cy + self.turn_radius * math.sin(t * math.pi / 2)
        elif self.direction == "est" and self.destination == "left":
            # Est -> Nord (virage à gauche)
            self.x = cx + self.turn_radius * math.cos(t * math.pi / 2)
            self.y = cy - self.turn_radius * math.sin(t * math.pi / 2)
        elif self.direction == "ouest" and self.destination == "right":
            # Ouest -> Nord (virage à droite)
            self.x = cx - self.turn_radius * math.cos(t * math.pi / 2)
            self.y = cy - self.turn_radius * math.sin(t * math.pi / 2)
        elif self.direction == "ouest" and self.destination == "left":
            # Ouest -> Sud (virage à gauche)
            self.x = cx - self.turn_radius * math.cos(t * math.pi / 2)
            self.y = cy + self.turn_radius * math.sin(t * math.pi / 2)
    
    def _get_distance(self, other):
        """Retourne la distance entre deux voitures"""
        return math.sqrt((self.x - other.x)**2 + (self.y - other.y)**2)
    
    def _check_collision(self, other):
        """Vérifie la collision avec une autre voiture (boîtes englobantes)"""
        # Si les voitures sont sur des directions différentes, vérifier moins strictement
        if self.direction != other.direction and not self.is_at_intersection:
            return False
            
        margin = 5
        return (self.x - self.width/2 - margin < other.x + other.width/2 and
                self.x + self.width/2 + margin > other.x - other.width/2 and
                self.y - self.height/2 - margin < other.y + other.height/2 and
                self.y + self.height/2 + margin > other.y - other.height/2)
    
    def _is_off_road(self):
        """Vérifie si la voiture a quitté la route"""
        if self.direction == "nord":
            return self.y < 80
        elif self.direction == "sud":
            return self.y > 720
        elif self.direction == "est":
            return self.x > 720
        elif self.direction == "ouest":
            return self.x < 80
        return False

    def draw(self, canvas):
        """Dessine la voiture sur le canvas"""
        x1 = self.x - self.width/2
        y1 = self.y - self.height/2
        x2 = self.x + self.width/2
        y2 = self.y + self.height/2
        
        # Si la voiture existe déjà, la déplacer
        if self.canvas_id is not None:
            canvas.coords(self.canvas_id, x1, y1, x2, y2)
        else:
            self.canvas_id = canvas.create_rectangle(
                x1, y1, x2, y2, 
                fill=self.color, 
                outline="black",
                tags=("car", f"car_{self.id}")
            )
        
        # Ajouter un petit indicateur de direction
        self._draw_direction_indicator(canvas)
    
    def _draw_direction_indicator(self, canvas):
        """Dessine un petit indicateur de direction"""
        if self.canvas_id is not None:
            # Supprimer l'ancien indicateur
            canvas.delete(f"dir_{self.id}")
        
        # Petit triangle pour indiquer la direction
        if self.direction == "nord":
            points = [self.x, self.y - self.height/2 - 2, 
                     self.x - 5, self.y - self.height/2 + 3,
                     self.x + 5, self.y - self.height/2 + 3]
        elif self.direction == "sud":
            points = [self.x, self.y + self.height/2 + 2,
                     self.x - 5, self.y + self.height/2 - 3,
                     self.x + 5, self.y + self.height/2 - 3]
        elif self.direction == "est":
            points = [self.x + self.width/2 + 2, self.y,
                     self.x + self.width/2 - 3, self.y - 5,
                     self.x + self.width/2 - 3, self.y + 5]
        else:  # ouest
            points = [self.x - self.width/2 - 2, self.y,
                     self.x - self.width/2 + 3, self.y - 5,
                     self.x - self.width/2 + 3, self.y + 5]
        
        canvas.create_polygon(points, fill="black", tags=(f"dir_{self.id}"))

    def remove(self, canvas):
        """Supprime la voiture du canvas"""
        if self.canvas_id is not None:
            canvas.delete(self.canvas_id)
            canvas.delete(f"dir_{self.id}")