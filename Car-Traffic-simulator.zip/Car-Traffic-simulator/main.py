import tkinter as tk
from traffic.Simulation import Simulation

class TrafficSimulatorApp:
    def __init__(self):
        # Fenêtre principale
        self.root = tk.Tk()
        self.root.title("Simulateur de Trafic - Carrefour à 4 Routes")
        # CORRECTION : la fenêtre était trop petite (800x700) pour son contenu
        # (canvas 800px + barre de boutons + barre de stats ≈ 920px), et comme
        # resizable était désactivé, les boutons étaient coupés/invisibles.
        # La barre de boutons flotte maintenant par-dessus le canvas (en haut
        # à droite), elle ne prend donc plus de place verticale séparée :
        # la fenêtre peut être un peu moins haute qu'avant.
        self.root.geometry("820x880")
        self.root.resizable(False, False)
        
        # Canvas pour la simulation
        self.canvas = tk.Canvas(self.root, width=800, height=800, bg="#2d8a2d")
        self.canvas.pack()
        
        # Barre de contrôle - positionnée en haut à droite, PAR-DESSUS le canvas
        # (place() avec relx=1.0 + anchor="ne" = ancré au coin supérieur droit)
        self.control_frame = tk.Frame(self.root, bg="#f0f0f0", bd=2, relief=tk.RAISED)
        self.control_frame.place(relx=1.0, y=10, x=-10, anchor="ne")
        
        # Boutons de contrôle (empilés verticalement dans le coin)
        self.start_button = tk.Button(self.control_frame, text="▶ Démarrer", 
                                     command=self.start_simulation, width=14,
                                     bg="lightgreen", font=("Arial", 10, "bold"))
        self.start_button.pack(side=tk.TOP, padx=8, pady=4, fill=tk.X)
        
        self.pause_button = tk.Button(self.control_frame, text="⏸ Pause", 
                                     command=self.pause_simulation, width=14,
                                     font=("Arial", 10, "bold"))
        self.pause_button.pack(side=tk.TOP, padx=8, pady=4, fill=tk.X)
        
        self.reset_button = tk.Button(self.control_frame, text="🔄 Réinitialiser", 
                                     command=self.reset_simulation, width=14,
                                     font=("Arial", 10, "bold"))
        self.reset_button.pack(side=tk.TOP, padx=8, pady=4, fill=tk.X)
        
        self.quit_button = tk.Button(self.control_frame, text="✕ Quitter", 
                                    command=self.root.quit, width=14,
                                    bg="lightcoral", font=("Arial", 10, "bold"))
        self.quit_button.pack(side=tk.TOP, padx=8, pady=4, fill=tk.X)
        
        # Statistiques
        self.stats_frame = tk.Frame(self.root, bg="#f0f0f0", relief=tk.RAISED, bd=2)
        self.stats_frame.pack(pady=10, fill=tk.X, padx=20)
        
        self.stats_label = tk.Label(self.stats_frame, 
                                   text="🚗 Voitures: 0 | Total générées: 0 | 🚦 Phase: Principale",
                                   font=("Arial", 12, "bold"),
                                   bg="#f0f0f0", fg="#333")
        self.stats_label.pack(side=tk.LEFT, padx=20, pady=5)
        
        self.time_label = tk.Label(self.stats_frame,
                                  text="⏱️ 00:00",
                                  font=("Arial", 12, "bold"),
                                  bg="#f0f0f0", fg="#333")
        self.time_label.pack(side=tk.RIGHT, padx=20, pady=5)
        
        # Créer la simulation
        self.simulation = Simulation(self.canvas)
        
        # Timer pour les statistiques
        self.update_stats()
        
        # Lancer l'application
        self.root.mainloop()
    
    def start_simulation(self):
        """Démarre la simulation"""
        if not self.simulation.running:
            self.simulation.start()
            self.start_button.config(text="⏹ En cours", bg="lightcoral")
            print("▶ Simulation démarrée")
    
    def pause_simulation(self):
        """Met en pause ou reprend la simulation"""
        if self.simulation.running:
            self.simulation.pause()
            if self.simulation.paused:
                self.pause_button.config(text="▶ Reprendre", bg="lightgreen")
                self.start_button.config(text="⏸ En pause", bg="orange")
            else:
                self.pause_button.config(text="⏸ Pause", bg="SystemButtonFace")
                self.start_button.config(text="⏹ En cours", bg="lightcoral")
    
    def reset_simulation(self):
        """Réinitialise la simulation"""
        self.simulation.reset()
        self.start_button.config(text="▶ Démarrer", bg="lightgreen")
        self.pause_button.config(text="⏸ Pause", bg="SystemButtonFace")
        print("🔄 Simulation réinitialisée")
    
    def update_stats(self):
        """Met à jour les statistiques affichées"""
        if hasattr(self, 'simulation'):
            # Compter les voitures actives
            active_cars = len([car for car in self.simulation.cars if car.state != "finished"])
            
            # Phase actuelle
            phase = "Principale (N/S)" if self.simulation.traffic_light_system.phase == "main" else "Latérale (E/O)"
            
            # Mettre à jour le label
            self.stats_label.config(
                text=f"🚗 Voitures: {active_cars} | Total générées: {self.simulation.total_cars_generated} | 🚦 Phase: {phase}"
            )
            
            # Mettre à jour le temps
            minutes = int(self.simulation.time_counter // 60)
            seconds = int(self.simulation.time_counter % 60)
            self.time_label.config(text=f"⏱️ {minutes:02d}:{seconds:02d}")
        
        # Planifier la prochaine mise à jour (toutes les secondes)
        self.root.after(1000, self.update_stats)


# Point d'entrée du programme
if __name__ == "__main__":
    # Créer et lancer l'application
    app = TrafficSimulatorApp()
